<?php 
//File name: AdminData.php
//This file presents the algorithm that must read the xml language and inserts relevant booking data onto the database.
//Uses a given file from FileUpload.php
session_start();
header('location: Bestroom.php');
$con = mysqli_connect("localhost","root","","room_bookings");
//loads file
$sxml = simplexml_load_file($_SESSION['file']) or die("Cant load xml"); 
//beginning of bookings
$startdate = date("Y-m-d",strtotime($_SESSION['start'])); 
$start=$startdate;
//end of bookings
$enddate = date("Y-m-d",strtotime($_SESSION['end'])); 
$_SESSION['day']= date('l', strtotime($startdate));
//changing startdate if it is a Saturday or a Sunday
if( $_SESSION['day']=='Saturday'){
    $startdate=date('Y-m-d', strtotime($startdate. ' + 2 days'));
    $_SESSION['day']=date('l', strtotime($startdate));
    }
elseif( $_SESSION['day']=="Sunday"){
    $startdate=date('Y-m-d', strtotime($startdate. ' + 1 days'));   
    $_SESSION['day']=date('l', strtotime($startdate));
    }
//finding the value of Monday on the week which contains $startdate
if ($_SESSION['day']=='Monday'){ 
    $start=$startdate;
}
elseif ($_SESSION['day']=='Tuesday'){
    $startdatr=date('Y-m-d', strtotime($startdate. ' - 1 days'));   
}
elseif ($_SESSION['day']=='Wednesday'){
    $startdate=date('Y-m-d', strtotime($startdate. ' - 2 days'));        
}
elseif ($_SESSION['day']=='Thursday'){
    $startdate=date('Y-m-d', strtotime($startdate. ' - 3 days'));      
}
elseif ($_SESSION['day']=='Friday'){
    $startdate=date('Y-m-d', strtotime($startdate. ' - 4 days'));
}
//Break is used as a trigger for when a booking is more that the end date
$break="False";
while($break=="False"){ 
        $currPeriod = 1;
        $currDay = 0; // 0 so we miss out the row headings
        $week=1;
        $countDay = 0; // counting the days after startdate
        foreach($sxml->SingleTimeTablesReport->TimeTables->TimetableData as $roomname)
        {
            $room = (string)$roomname->ResourceName;
            $room = preg_replace("/^Timetable\s*\\-\s*/","", $room);
            foreach($roomname->TableRow as $period)
            {              
                foreach($period->CellData as $cellData)
                {
                    if ($cellData=='Bef' or $cellData=='Lun' or $cellData=='Aft' or $cellData=='' )
                    {
                    //Break time, lunch time and after school time being ignore for the project
                    }
                    elseif($cellData==1 or $cellData==2 or $cellData==3 or $cellData==4 or $cellData==5 ){
                        $Period=$cellData;
                        $currDay = 0;
                    }
                    else
                    {
                        $cellRowCount = 0; 
                        foreach($cellData->CellRow as $cellRow){
							
                            if ((string)$cellRow != ""){
								//disregarding empty rows
                                if ($cellRowCount == 0){
                                    if ($week==1){
                                        $bookdate = date('Y-m-d', strtotime($startdate. ' + ' . ($currDay-1) . 'days'));
										//minus one so that it adds the correct number of days (plus five will be too large)
                                    }
                                    else{
                                        $bookdate = date('Y-m-d', strtotime($startdate. ' + ' . ($currDay+6) . 'days'));
										//adjusting for the two week timetable
                                    }
                                    if (strtotime($bookdate)>=strtotime($enddate)){
										//checking when to break while loop
                                    	$break="True";
                                    }
									//increases cellRowCount so that it wont treat it as the first row next time 
                                    $cellRowCount += 1;                                    
                                }
								else{                   
									// Getting Teacher                                    
									$teacher=(string)$cellRow;
                                    $cellRowCount = 0;
                                    $countDay += 1;
									$trimteacher=rtrim($teacher);
									$result = str_replace("Mrs", "", $trimteacher);
									//stripping title from name by checking if each one worked
									if ($trimteacher==$result){
										$result = str_replace("Miss", "", $trimteacher);
										if ($trimteacher==$result){
											$result = str_replace("Mr", "", $trimteacher);
										}
									}
                                    if (strtotime($bookdate)>strtotime($enddate) or strtotime($bookdate)<strtotime($start) ){ 
										//checking which dates don't meet the requirements and should not be booked
                                    }
                                    else{
										//Any previous bookings with the same time and room will be overwritten so it must be deleted first
										$sql="Delete FROM `Bookings` WHERE Date= '$bookdate' AND LessonNo='$Period' and RoomName='$room'";
        								$out = mysqli_query($con, $sql);
										//The new booking is insterted into the database
										$sql = "INSERT INTO `Bookings` (`RoomName`, `Username`, `Date`, `LessonNo`) VALUES ('$room', '$result', '$bookdate', '$Period')";
            							$con->query($sql);                           
                                    }                                            
                                }                   
                            }
                        }
                    } 
					//toggle between week 1 and week 2
                    if($currDay == 5 and $week==1){ 
                        $currDay = 1;
                        $week=2;
                    }
                    elseif($currDay == 5 and $week==2){
                        $currDay = 1;
                        $week=1;
                    }
                    else{
						//if it is not a friday, CurrDay is incremented
                        $currDay += 1;                        
                    }
                    }
            }
        }
	//When week 1 and week 2 have been passed through, days increase by 14 so that it begins the next cycle
    $startdate = date('Y-m-d', strtotime($startdate. ' + ' . '14 days'));
}  
?>