<html>
	<i-- Filename: Bestroom.php
		 This file displays a list of the computer rooms to the user and allows them to
		 select the most suitable room to access the timetable with. It also contains
		 other submit buttons to take admins to other pages.--></i-->
	<head>
		<i-- Style sheets are used to separate the page into two main parts, selecting the best room and 
			 direct booking. It is also used to appropriately place the sumbit buttons.--></i-->
		<style>
			div.Bestroom{
				background-color: #6CCBAA;
				border-radius: 20px;
				border-color: white;
				border-style: dotted;
				border-width: 7px;
				padding: 20px; 
				color: white;
				margin: 20px 0 20px 0;
				height:600px;
				width:40%;
				position: absolute;
				top: 20%;
				left:5%;
			}
			div.Book{
				background-color: #6CCBAA;
				border-radius: 20px;
				border-color: white;
				border-style: dotted;
				border-width: 7px;
				padding: 20px; 
				color: white;
				margin: 20px 0 20px 0;
				color: white;
				margin: 20px 0 20px 0;
				padding: 20px;
				height:600px;
				width:40%;
				position: absolute;
				top: 20%;
				left: 52.5%;
			}
			h1{
				text-align: center;
			}
			input[type=submit].Direct {
				padding:5px 13px; 
				background-color: #009AAA;
				border: 2px solid white;
				font-size: 25px;
				width:100%;
				cursor: pointer;
				float:right;
			}
			input[type=submit].Direct:hover {
				background-color: white;
				color:#009AAA;
			}
			input[type=submit].logout {
				float: right;
				transform: translate(0%, -500%);
			}
			input[type=submit].Bestroom {
				padding:3px 13px; 
				background-color: #009AAA;
				border: 1px solid white;
				font-size: 20px;
				width:80%;
				cursor: pointer;
			}
			input[type=submit].Bestroom:hover {
				background-color: white;
				color:#009AAA;
			}
			input[type=submit].constant:hover {
				color:#009AAA;
			}
			input[type=submit].logout:hover {
				color:#009AAA;
			}
		</style>
	</head>
	<i-- These forms are used by the admins to access features such as uploading a file 
		 deleting multiple bookings and creating accounts--></i-->
    <body style="background-color:#4ABDAC;">
		<form action = "" method = "post" >
        	<label>Upload XML File to Database (ADMIN ONLY): </label><input class="constant" type = "submit" value = "Upload" name="Upload"/>   
		</form>
		<form action = "" method = "post" >
        	<label>Delete All Bookings before a given date (ADMIN ONLY):  </label><input class="constant" type = "submit" value = "Update" name="Update"/>    
		</form>
		<form action = "" method = "post" >
        	<label>Teacher Sign Up (ADMIN ONLY): </label><input class="constant" type = "submit" value = "Signup" name="Signup"/>     
		</form>
		<i-- This button will sign the user out, deleting the session in the process--></i-->
		<form action = "Logout.php" method = "post">
      		<input class ="logout" type = "submit"  value = " Logout "/><br />
    	</form>
		<?php
		session_start();
		// checks if the user has signed in. If they have not then they will be returned to the login screen.
		if(!isset($_SESSION['login_user'])){
    		header("location: Login.php");
		}
		//Moves the user to a diffrerent page according to which button they selected.
		if(isset($_POST['Upload']) and $_SESSION['Admin']==1){
			header("location: UploadForm.php");
		}
		if(isset($_POST['Update']) and $_SESSION['Admin']==1){
			header("location: Update.php");
		}
		if(isset($_POST['Signup']) and $_SESSION['Admin']==1){
			header("location: Signup.php");
		}
		?>
        <div class="Bestroom">
            <h1>Find the Best Room:</h1>
			<i-- Lists the resources so that the user can select which ones they want --></i-->
            <form action = "" method = "post">
                <label>Resources:</label><br>
                <input type="checkbox" name="resource1" value="Printer"/> Printer<br>
                <input type="checkbox" name="resource2" value="Whiteboard"/> Whiteboard<br>
                <input type="checkbox" name="resource3" value="Interactive Whiteboard"/> Interactive Whiteboard<br>
                <input type="checkbox" name="resource4" value="Scanner"/> Scanner<br>
                Number of Students: <input type="number" name="Students" /><br>
                <input class="constant" type = "submit" value = " Submit "/>
			</form>
			<?php
			//Defining the arrays that will be changed throughout the algorithm
			$order=array();
			$compare = array();
			$score=array();
			$result=array();
			$resources=array();
			$roomvalues = array();
			$comps = array();
			$names=array();
			//Obtaining all relevent room information - Name, resources includes and the number of computers
			$con = mysqli_connect("localhost","root","","room_bookings");  
            $sql="Select RoomName, RoomResources, ComputerNumber FROM Rooms";
			$query = mysqli_query($con, $sql);
			while ($row = $query->fetch_assoc()){
				$roomstring=array();
				//All of the room names are stored in a array
				array_push($names, $row['RoomName']);
				//All of the computer numbers are stored in a array
				array_push($comps, $row['ComputerNumber']);
				//The resources found in each room are seperated into their own array 
				for ($room = 0; $room < strlen($row['RoomResources']); $room++){
					array_push($roomstring, $row['RoomResources'][$room]); 				
				}
				//Then the array of resources is placed into a two-dimensional array (for each room)
				array_push($roomvalues, $roomstring);
			} 
			if (isset($_POST['Students'])){
				//caluculates the difference between the number of computers and number of studnets entered for each room
				 for ($room = 0; $room < count($comps) ; $room++){
					 $answer=($comps[$room])-($_POST['Students']);
					 //If the result is positive, then it is made negative so that all answers are measured by size only.
					 if ($answer>0){
						 $answer=$answer*-1;
						 array_push($result,$answer);
					 }
					 else{
						 array_push($result,$answer);
					 }
				}
				//Identifies and creates an array of the resources selected by the user with POST
				if (isset($_POST['resource1'])){
					array_push($resources,'P');
				}
				if (isset($_POST['resource2'])){
					array_push($resources,'W');
				}
				if (isset($_POST['resource3'])){
					array_push($resources,'I');
				}
				if (isset($_POST['resource4'])){
					array_push($resources,'S');
				}
			//The first loop iterates through each computer room
			for ($room = 0; $room  < count($roomvalues); $room++){
				$sim=0;
				$diff=0;
				//The second loop iterates through each resource input by the user
				for ($index = 0; $index < count($resources) ; $index++){
					 $check=0;
					//The third loop iterates through each resource found stored within each room 
					//(using $room from the first loop)
					 for ($res = 0; $res < count($roomvalues[$room]); $res++){
						 //If an input resource is found within the current room
						if ($resources[$index]==$roomvalues[$room][$res]){
							//Number of similariteies is incremented by 1
							$sim=$sim+1;
						}
						else{
							//The check variable is incremented by 1
							$check=$check+1;
						}
					 }
					//check is used to determine if any of the resources input is not found within a room
					if ($check==count($roomvalues[$room])){
						//Number of differences is incremented by 1
						$diff=$diff+1;
					}
				}
				//A total value is calculated by adding differences to anything that is not 'similar'
				$diff= $diff + (count($roomvalues[$room])-$sim);
				//This is calculated per room
				$list=array($sim,$diff);
				//Each rooms values are stored in a two-dimensional array
				array_push($compare,$list);
			}
			//This loop iterates through each of the computer room results
			for ($loop = 0; $loop < count($compare); $loop++){ 
				//A score is calulated using $sim, $diff and the difference between computers and students
				$res=(($compare[$loop][0]-$compare[$loop][1])*2)+$result[$loop];
				//Each score is stored within this associative array with the room name corresponding to it
				$score[$names[$loop]] = $res;
			}
				//The list is sorted in descending order
				arsort($score);
				echo "The Rooms in order of suitability (A higher score means better suitability): <br>";
				//Each of the rooms in the associative array $score is output in descending order
				foreach($score as $outcome => $outcome_value) {
					echo "<form action = 'Table.php' method = 'post'>";
					//Output as a button so that the user can interact with it 
					echo "<input class='Bestroom' type = 'submit' value = '$outcome' name= 'room' ></input><label> Score = " . $outcome_value . "</label>";
					echo "</form>";
				}

			}       
			?>
        </div>
		<i-- Direct Booking will list the rooms as buttons in a constant order so that users can skip the 
			 best room algorithm and go straight to the timetable--></i-->
        <div class="Book">
            <h1>Direct Booking:</h1>  
            <?php
            echo "<form action = 'Table.php' method = 'post'>";
			$con = mysqli_connect("localhost","root","","room_bookings");  
			//selects all of the rooms from the database
            $sql="Select RoomName FROM Rooms";
			$result = mysqli_query($con, $sql);
				if (mysqli_num_rows($result) > 0) {
					while ($row = $result->fetch_assoc()){
						//outputs all of the rooms found in the database as a button
						echo "<input class='Direct' type='submit' value='{$row['RoomName']}' name='room' ></input><br><br><br>";
					}
				}
			echo "</form>";
            ?>
        </div>		
    </body>
</html>
