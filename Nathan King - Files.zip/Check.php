<html>
    <body>
        <?php
		//Filename: Check.php
		//This file is used to validate the user's input details given in Login.php.If the details 
		//are correct, then a ‘login’ occurs and the user can be transferred to the next web page.
        session_start();
		//conects to the database
        $con = mysqli_connect("localhost","root","","room_bookings");
		//uses md5 hash on the input password so that it can be used to compare with the stored password
		$password=md5($_POST['password']);
		//selects the teacher record with the same username and password that was input
        $sql = "SELECT TeacherID, Username, Password, IsAdmin FROM Teacher Where Username='{$_POST['username']}' AND Password='$password'";
        $result = mysqli_query($con, $sql);
		//If a result has been returned (rows is greater than 0)
        if (mysqli_num_rows($result) > 0) {
			//Sign in is successful
			$row = $result->fetch_assoc();
			//Store username and admin value globally to use on other files
			$_SESSION['login_user']=$_POST['username'];
			$_SESSION['Admin']=$row['IsAdmin'];
			//Take user to next page
            header("location: Bestroom.php");
            }
		else{
			//Return user back to login page if sign in is unsuccessful
			header("location: Login.php");			
		}
        mysqli_close($con);
        ?>
    </body>
</html>

