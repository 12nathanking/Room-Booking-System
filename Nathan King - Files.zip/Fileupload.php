<?php
//Filename: FileUpload.php
//This file is used to validate the file selected by the user from
//UploadForm.php and will then send the data to AdminData.php
session_start();
//Makes start date and end date global
$_SESSION['start']=$_POST['startdate'];
$_SESSION['end']=$_POST['enddate'];
//specifies the directory where the file is going to be placed
$target_dir = "uploads";
//specifies the path of the file to be uploaded
$target_file = $target_dir . basename($_FILES["File"]["name"]);
//Identifies the type of file it is
$filetype = pathinfo($_FILES["File"]["name"],PATHINFO_EXTENSION); 
//checks for duplicate filename
if (file_exists($target_file)) {
	//deletes the duplicate file
	unlink($target_file); 
}
if(isset($filetype)){
	//checks if the file is xml
	if($filetype == "xml"){ 
		//then the file is uploaded
		if (move_uploaded_file($_FILES["File"]["tmp_name"], $target_file)) {
			$_SESSION['file']=$target_file;
			//Take user to the next page
			header("location: AdminData.php");
		} 
	}
	//If the file input was not valid or an error has occured then the user is taken 
	//back to the previous page
	else {
		header("location: UploadForm.php");
	}
}
//If the file input was not valid or an error has occured then the user is taken 
//back to the previous page
else{
	header("location: UploadForm.php");
}
?>