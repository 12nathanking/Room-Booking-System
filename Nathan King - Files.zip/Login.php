<html>    
	<head>
		<i-- Filename: Login.php
			 This file acts as a login page for users where they will enter their 
			 username and password to be sent to Check.php to check for validity.
			 Style sheets are used to place the input boxes within the centre of the screen
			 as well as change the base colours--></i-->
		<style>
			h1 {
				position: relative;
				font-weight:bold;
				font-size:50px;
				top:100px;
				color: white;
				font-family: "Courier New", Courier, monospace;
				text-align: center;
				text-decoration: underline; 
				}
			input[type=text], input[type=password] {
				font-weight:bold;
				background-color: #6CCBAA;
				color:white;
				width: 100%;
				padding: 12px 20px;
				margin: 8px 0;
				box-sizing: border-box;
			}
			input[type=submit] {
				width: 100%;
				background-color: powderblue;
				color: white;
				padding: 15px 20px;
				margin: 8px 0;
				border: none;
				border-radius: 4px;
				cursor: pointer;
				font-weight:bold;
			}
			*::-webkit-input-placeholder {
				color: white;
				text-align: center;
			}
			input[type=submit]:hover {
				background-color: white;
				color:powderblue;
			}
			#corner {
				border-radius: 20px;
				border-color: white;
				border-style: dotted;
				border-width: 7px;
				padding: 20px; 
				width: 30%;
				position: fixed;
				top: 28%;
				left: 34%;
			}
		</style>
	</head>
   <h1>SIGN IN</h1>
   <body style="background-color:#4ABDAC;">
    <?php
	session_start();
	//checks if the user has already logged in
	if(isset($_SESSION['login_user'])){
		//directs the user to the next page if true
    	header("location: Bestroom.php");
	}	   
	?>
	   	<i-- Takes the user to Check.php when they submit this form --></i-->
         <form action = "Check.php" method = "post">
         <p id="corner">
		 <i-- Asks the user to input their username and pasword --></i-->
         <input type = "text" color= "white" Placeholder = "Username" name = "username" class = "box"/><br /><br />    
         <input type = "password" Placeholder = "Password" name = "password" class = "box" /><br/><br />
         <input type = "submit" value = " Submit "/><br /></p>
       </form>
   </body>
</html>