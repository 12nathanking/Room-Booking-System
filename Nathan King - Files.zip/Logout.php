<?php
//Filename: Logout.php
//This file is used to sign a teacher out of the system
session_start();
//All of the global variables are deleted
session_destroy();
//The user is taken to the login page
header("location: Login.php")
?>