<html>
	<i-- Filename: Signup.php
		 This file is used to allow the admin to create a new user account
		 It validates the input details to make sure it meets they requirements--></i-->
	<head>
		<style>
			input[type=text], input[type=password]{
				width: 200px;
			}
		</style>
	</head>
	<body style="background-color:#4ABDAC;">
		<form action = "" method = "post">
			<i-- Asks the admin to input a username for the new account--></i-->
			<label>Input Username (Identical to Sims Data): </label><input required type = "text" Placeholder = "Username" name = "username"/><br /><br />
			<i-- Asks the admin to input a password for the new account--></i-->
			<label>Input Password: </label><input required type = "password" Placeholder = "Password" name = "password"/><br /><br />    
			<i-- Asks the admin to select if the new account can access admin features--></i-->
			<input type="checkbox" name="AdminValue"/> Is the User going to be an Admin?<br>
			<input type = "submit" name = "Submit"/><br /> 
		</form>
		<i-- This submit button will take the user back to the previous page--></i-->
		<form action = "Bestroom.php" method = "post">
			<input type = "submit" value = "Return" name = "Return"/><br />   
    	</form>
		<?php
		session_start();
		// checks if the user has signed in. If they have not then they will be returned to the login screen
		if(!isset($_SESSION['login_user'])){
    		header("location: Login.php");
		}
		if(isset($_POST['username'])){
			if (!preg_match("/^(([A-Z]\s[A-Z]\s[A-Z]\w+)|([A-Z]\s[A-Z]\w+))$/",$_POST['username'])){
				echo "Invalid input for username"; 
			}
			else{
				//count is made to equal 1 
				//It will be used later to determine a successful input 
				$count=1;
			}
		}
		//If the user selected to have the account be an admin
		if(isset($_POST['AdminValue'])){
			//Admin = True
			$AdminValue=1;
		}
		else{
			//Admin=False
			$AdminValue=0;
		}
		//If the username input meets the requirements
		if($count==1){
			//Md5 hash the password for security before storing it
			$password=md5($_POST['password']);
			$con = mysqli_connect("localhost","root","","room_bookings");
			//Checks if there is already an account/user with the same username
			$sql = "SELECT Username FROM Teacher Where Username='{$_POST['username']}'";
			$result = mysqli_query($con, $sql);
			//If this username is being used
			if (mysqli_num_rows($result) > 0) {
				echo "Username already in use.";

					}
			//If this username is available
			else{
				//Insert details into the Teacher table
				$sql = "INSERT INTO `Teacher` (`TeacherID`, `Username`, `Password`, `IsAdmin`) VALUES (NULL, '{$_POST['username']}', '{$password}', '{$AdminValue}')";
				if ($con->query($sql) === TRUE) {
					//return the user to the previous page
					   header("Location: Bestroom.php");
					} 
					else {
						echo "Error: " . $sql . "<br>" . $con->error;
					}
			}
		}
		?>
	</body>
</html>