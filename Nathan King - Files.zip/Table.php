<html>
	<i-- Filename: Table.php
		 This file is used to display the bookings for each computer room in a table so that
		 the user can select and interact with the cells. The timetable can be managed with 
		 different menus.--></i-->
	<head>
		<i-- Style sheets are used to display the table appropriately and highlight interactions></i-->
		<style>
			h1 {
				position:relative;
				top:15px;
				color:white;
				text-align: center;
				text-decoration: underline;   
				font-weight:bold;
				font-size:40px;
				font-family: "Courier New", Courier, monospace;
				}
			table, th, td {
				border: 4px solid;
				border-color:powderblue;
			}
			table {
				border-collapse:collapse;
				height:600px;
			}
			th, td {
				padding: 15px;
			}
			th {
				background-color: white;
				font-size: 30px;
			}
			td{
				font-size:25px;
				text-align: center;
				}
			td:hover {
				background-color: powderblue;
			}
			a:link    {
				background-color:transparent; text-decoration:none
			}
			a:hover   {
				color:red; background-color:transparent; text-decoration:underline
			}
			a:active  {
				color:yellow; background-color:transparent; text-decoration:underline
			}
			input.left{ 
				transform: translate(900%, -600%);
			}
			input.right{
				transform: translate(1900%, -422%);
			}
		</style>
	</head>
    <body style="background-color:#4ABDAC;">
<?php
session_start();
//checks if the user has signed in. If they have not then they will be returned to the login screen
if(!isset($_SESSION['login_user'])){
    header("location: Login.php");
}
//checks if the user has come from the View.php page
if(isset($_POST['return']) or isset($_SESSION['edit'])){
    unset($_SESSION['edit']);
	//uses global date for the timetable and calculates the day of the week
    $_SESSION['day']=date('l', strtotime($_SESSION['date']));
}
//checks if the user has selected to change the room
elseif(isset($_POST['changeroom'])){
	//changes the room of the timetable globally
    $_SESSION['room']=$_POST['room'];
}
//checks if the user has selected the 'next' button
elseif(isset($_POST['Next'])){
	//increases the gloabl date by 7 days in order to move the timetable to the next week
    $_SESSION['date']=date('Y-m-d', strtotime($_SESSION['date']. ' + 7 days'));
	//calculates the day of the week
	$_SESSION['day']=date('l', strtotime($_SESSION['date']));
}
//checks if the user has selected the 'previous' button
elseif(isset($_POST['Previous'])){
	//decreases the gloabl date by 7 days in order to move the timetable to the previous week
	$_SESSION['date']=date('Y-m-d', strtotime($_SESSION['date']. ' - 7 days'));
	//calculates the day of the week
	$_SESSION['day']=date('l', strtotime($_SESSION['date']));

}
//checks if the user has selected to change the date directly
elseif(isset($_POST['date'])){
	//uses the current room
    $room=$_SESSION['room'];
	//changes the inputdate to the one which was input
    $inputdate=$_POST['date'];
	//if date is 'irrelivant' (before the 6th of March 2017)
    if ($inputdate<date('2017-03-06')){
        echo "This date cannot be used";
    }
    else{
		//make variables global
        $_SESSION['date']=$inputdate;
		//calculates the day of the week
        $_SESSION['day']= date('l', strtotime($_POST['date']));
    }
}
//used when the user first arrives on the page
else {
	//makes the global date the current date
    $_SESSION['date']= date('Y-m-d');
	//obtains the room input from Bestroom.php
    $_SESSION['room']=$_POST['room'];
	//calculates the day of the week
    $_SESSION['day']=date('l', strtotime($_SESSION['date'])); 
}
//if the day of the week is a Saturday   
if( $_SESSION['day']=='Saturday'){
	//Increase the date by two days
    $_SESSION['date']=date('Y-m-d', strtotime($_SESSION['date']. ' + 2 days'));
	//Calculate the day (this will be a Monday)
    $_SESSION['day']=date('l', strtotime($_SESSION['date']));
    }
//if the day of the week is a Sunday   
elseif( $_SESSION['day']=="Sunday"){
	//Increase the date by one day
    $_SESSION['date']=date('Y-m-d', strtotime($_SESSION['date']. ' + 1 days')); 
	//Calculate the day (this will be a Monday)
    $_SESSION['day']=date('l', strtotime($_SESSION['date']));
    }
//if the day is a Monday
if ($_SESSION['day']=='Monday'){
	//The start of the week (Monday) is made the global date 
    $start=$_SESSION['date'];
	//The end of the week (Friday) is made 4 days more than the global date
    $end=date('Y-m-d', strtotime($_SESSION['date']. ' + 4 days'));
}
//if the day is a Tuesday
elseif ($_SESSION['day']=='Tuesday'){
	//The start of the week (Monday) is made 1 day less than the global date
    $start=date('Y-m-d', strtotime($_SESSION['date']. ' - 1 days'));
	//The end of the week (Friday) is made 3 days more than the global date
    $end=date('Y-m-d', strtotime($_SESSION['date']. ' + 3 days'));    
}
//if the day is a Wednesday		
elseif ($_SESSION['day']=='Wednesday'){
	//The start of the week (Monday) is made 2 days less than the global date
    $start=date('Y-m-d', strtotime($_SESSION['date']. ' - 2 days'));
	//The end of the week (Friday) is made 2 days more than the global date
    $end=date('Y-m-d', strtotime($_SESSION['date']. ' + 2 days'));        
}
//if the day is a Thursday
elseif ($_SESSION['day']=='Thursday'){
	//The start of the week (Monday) is made 3 days less than the global date
    $start=date('Y-m-d', strtotime($_SESSION['date']. ' - 3 days'));
	//The end of the week (Friday) is made 1 days more than the global date
    $end=date('Y-m-d', strtotime($_SESSION['date']. ' + 1 days'));       
}
//if the day is a Friday	
elseif ($_SESSION['day']=='Friday'){
	//The start of the week (Monday) is made 4 days less than the global date
    $start=date('Y-m-d', strtotime($_SESSION['date']. ' - 4 days'));
	//The end of the week (Friday) is made the global date
    $end=$_SESSION['date'];
}
//Creating the timetable
echo " <h1> Bookings on week starting ". date('d-m-Y',strtotime($start)) . " with room ".$_SESSION['room'] .":" . "</h1>"."<br>";
$con = mysqli_connect("localhost","root","","room_bookings");  
echo "<table style='width:100%'>";
//Output all table headings
echo "<th>"." Lesson "."</th>";
echo "<th>"." Monday - " . date('d-m-Y', strtotime($start)) . "</th>";
echo "<th>"."Tuesday - " . date('d-m-Y', strtotime($start. ' + 1 days')) . "</th>";
echo "<th>"."Wednesday - " . date('d-m-Y', strtotime($start. ' + 2 days')) . "</th>";
echo "<th>"."Thursday - " . date('d-m-Y', strtotime($start. ' + 3 days')) . "</th>";
echo "<th>"."Friday - " . date('d-m-Y', strtotime($start. ' + 4 days')) . "</th>";    
for($count=1; $count<=5; $count ++){
    $date=$start;
	//begin a table row
    echo "<tr>" . "<td>" . $count . "</td>";
	$date=date('Y-m-d', strtotime($date));
    for($colcheck=1; $colcheck<=5; $colcheck ++){
        $sql="SELECT * FROM `Bookings` WHERE Date = '$date' AND RoomName='{$_SESSION['room']}' AND LessonNo='$count' ORDER BY Date ASC";
        $result = mysqli_query($con, $sql);
		//If there is a booking with the given date, room name and lesson number
        if (mysqli_num_rows($result) > 0) {
            while ($row = $result->fetch_assoc()){
            echo  "<td>"; 
			//make the cell contain a hyperlink with the username of the booking owner
            ?>
            <a href="View.php?id=<?php echo $row['Username']?>&date=<?php echo $row['Date']?>&bref=<?php echo $row['BookingNo']?>&lesson=<?php echo $row['LessonNo']?>&room=<?php echo $row['RoomName']?>" > <?php echo $row['Username']; ?> </a>
            <?php
            echo "</td>";  
            }
        }
        else {
            echo "<td>"
			//make the cell contain a hyperlink that says 'empty'
            ?>
            <a href='View.php?date=<?php echo $date?>&lesson=<?php echo $count?>&room=<?php echo $_SESSION['room']?>'> Empty </a>
            <?php
            echo "</td>";
        }
		//increment the current date of the timetable by 1
        $date=date('Y-m-d', strtotime($date. '+ 1 days'));
    }   
		//end a table row
        echo "</tr>";
} 
echo "</table>";
?>
	<i-- This form allows the user to change to timetable by selecting a room --></i-->
    <form action = "" method = "post" >
        <label>Room Name  :</label>
        <select name="room"><?php
			$sql="Select RoomName FROM Rooms";
			$result = mysqli_query($con, $sql);
				if (mysqli_num_rows($result) > 0) {
					while ($row = $result->fetch_assoc()){
						echo $row['RoomName'];
						//lists each room in the order obtained from the database
						echo "<option value=".$row['RoomName'] . ">" . $row['RoomName'] . "</option>";
					}
				}
			?>
        </select><br />
        <input type = "submit" value = " Change Room " name="changeroom"/><br />
    </form>
	<i-- This form allows the user to change to timetable by selecting a date --></i-->
    <form action = "" method = "post" >
        <label>Date  :</label><input type = "date" name = "date" class = "box" /><br/>
        <input type = "submit" value = " Change Date " name="changedate"/><br />     
    </form>
	<i-- This form allows the user to logout by taking them to Logout.php --></i-->
    <form action = "Logout.php" method = "post">
      <input type = "submit"  value = " Logout "/><br />
    </form>
	<i-- This form allows the user to return to the Bestroom.php page --></i-->
	<form action = "Bestroom.php" method = "post">
		<input type = "submit" value = "Return" name = "Return"/><br />   
    </form>
	<i-- This form allows the user to change to timetable by going forward a week --></i-->
	<form action = "" method = "post">
		<input class="right" type = "submit" value = ">>>>>>" name = "Next"/><br />    
    </form>
	<i-- This form allows the user to change to timetable by going back a week --></i-->
	<form action = "" method = "post">
		<input class="left" type = "submit" value = "<<<<<<" name = "Previous"/><br />   
    </form>
    </body>
</html>