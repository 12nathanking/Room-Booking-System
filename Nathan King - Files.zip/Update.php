<html>
	<i-- Filename: Update.php
		 This file is used to allow an admin to delete all bookings up to a given date--></i-->
	<body style="background-color:#4ABDAC;">
		Please select a date in which bookings will be deleted up to.
		<i-- The user inserts a date into the box and submits the input --></i-->
		<form action = "" method = "post" >
        	<label>Date  :</label><input required type = "date" name = "date" /><br/>
        	<input type = "submit" value = " Submit " name="submit"/><br />     
    	</form>
		<form action = "Bestroom.php" method = "post">
			<input type = "submit" value = "Return" name = "Return"/><br />   
    	</form>
		<?php
		session_start();
		// checks if the user has signed in. If they have not then they will be returned to the login screen
		if(!isset($_SESSION['login_user'])){
    		header("location: Login.php");
		}
		//if the admin has input a date
		if (isset($_POST['date'])){
			$con = mysqli_connect("localhost","root","","room_bookings");
			$removedate=date("Y-m-d", strtotime($_POST['date']));
			//All of the bookings before the date input are deleted
			$sql="Delete FROM `Bookings` WHERE Date < '$removedate' ";
			$result = mysqli_query($con, $sql);
			//The user is returned to the previous page
			header('location: Bestroom.php');
		}
		?>
	</body>
</html>
