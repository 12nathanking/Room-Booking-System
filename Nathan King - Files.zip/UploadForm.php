<!DOCTYPE html>
<html>
	<i-- Filename: UploadForm.php
		 This file is used to allow an admin to select a file to upload, where 
		 it will be validated in another page--></i-->
	<body style="background-color:#4ABDAC;">
		<form action="Fileupload.php" method="post" enctype="multipart/form-data">
			Select the file to upload:
			<input required type="file" name="File" id="FileUpload">
			<label>Start Date:</label>
			<input required type = "date" value = "Start Date" name="startdate"/>
			<label>End Date:</label>
			<input required type = "date" value = "End Date" name="enddate"/>
			<input type="submit" value="Upload File" name="UploadFile"/>
		</form>
		<form action = "Bestroom.php" method = "post">
			<input type = "submit" value = "Return" name = "Return"/><br />   
    	</form>
		<?php
		session_start();
		// checks if the user has signed in. If they have not then they will be returned to the login screen.
		if(!isset($_SESSION['login_user'])){
    		header("location: Login.php");
		}
		?>
	</body>
</html>