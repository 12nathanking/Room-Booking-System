<?php
//Filename: View.php
//This file is used to allow the user to view the selected cell in the timetable, where they can then
//create a booking, delete a booking or return without any changes made.
session_start();
// checks if the user has signed in. If they have not then they will be returned to the login screen
if(!isset($_SESSION['login_user'])){
    header("location: Login.php");
}
// checks if the user has selected a room. If they have not then they will be returned to the Table.php page
if(!isset($_GET['room'])){
    header("location: Table.php");
}
$_SESSION['date']=$_GET['date'];
?>
<html>
	<head>
		<i-- Style sheets are used to separate the page into two main parts, viewing the room resources and viewing
			 the (potential) booking. It is also used to appropriately place the sumbit buttons.--></i-->
		<style>
			div.Room{
				background-color: #6CCBAA;
				border-radius: 20px;
				border-color: white;
				border-style: dotted;
				border-width: 7px;
				padding: 20px; 
				color: white;
				margin: 20px 0 20px 0;
				height:400px;
				width:40%;
				transform: translate(5%, 5%);
			}
			div.Book{
				background-color: #6CCBAA;
				border-radius: 20px;
				border-color: white;
				border-style: dotted;
				border-width: 7px;
				padding: 20px; 
				color: white;
				margin: 20px 0 20px 0;
				color: white;
				margin: 20px 0 20px 0;
				padding: 20px;
				height:400px;
				width:40%;
				position: fixed;
				transform: translate(120%, -104%);
			}
			h1{
				text-align: center;
			}
			p{
				font-size:25px;
			}
			li{
				font-size:25px;
			}
			form.btn1{
				position: fixed;
				top: 80%;
				left:84%;
			}
			form.btn2{
				position: fixed;
				top: 80%;
				left:44%;
			}
			form.btn3{
				position:fixed;
				top: 80%;
				left:5%;
			}
		</style>
	</head>
    <body style="background-color:#4ABDAC;">
        <div class="Room">
            <h1>Room Details- <?php echo $_GET['room']?></h1>
            <p>
            <?php
				//obtain information about the selected room from the database
                $sql="Select * FROM Rooms WHERE RoomName='{$_GET['room']}'";
                $con = mysqli_connect("localhost","root","","room_bookings");
                $result = mysqli_query($con, $sql);
                if (mysqli_num_rows($result) > 0) {
                    while ($row = $result->fetch_assoc()){
                        $objects = $row['RoomResources'];
                        $length = strlen($objects);
                        echo "<br>" . "Number of Computers: " . $row['ComputerNumber'] . "<br>";
                        echo "<br>" . "Rescources Included:";
						//loop through all of the letters in $objects
                        for($count=0; $count<$length; $count ++){
							//If I is in $objects, output Interactive WhiteBoard
                            if (substr($objects,$count,1)=='I'){
                                echo "<li>" . "Interactive WhiteBoard" ."</li>" . "<br>";
                            }
							//If S is in $objects, output Scanner
                            elseif (substr($objects,$count,1)=='S'){
                                echo "<li>" . "Scanner" ."</li>" . "<br>";
                            }
							//If P is in $objects, output Printer
                            elseif (substr($objects,$count,1)=='P'){
                                echo "<li>" . "Printer" ."</li>" . "<br>";
                            }
							//If W is in $objects, output WhiteBoard
                            elseif (substr($objects,$count,1)=='W'){
                                echo "<li>" . "WhiteBoard" ."</li>" . "<br>";
                            }
                        }
                    }
                }
            ?>
            </p>
        </div>
        <div class="Book">
            <h1>Booking Details</h1>
            <p>
                <?php
                    echo "<br>" ."Room : " . $_GET['room'] . "<br>";
                    echo "Date: " . date('d-m-Y', strtotime($_GET['date'])) . "<br>";
					//if the day of the chosen date is a friday, use friday lesson times
                    if (date('l', strtotime($_GET['date']))=='Friday'){
                        $day = 'TimeF';
                    }
					//if the day chosen is not a friday, use Monday to Thursday lesson times
                    else{
                        $day = 'TimeMT';
                    }
					//find the day of the chosen date
                    $dayname= date('l', strtotime($_GET['date']));
                    echo "Day: " . $dayname  . "<br>";  
                    echo "Lesson Number: " . $_GET['lesson'] . "<br>";
                    $sql="Select * From `Lesson_Times` WHERE LessonNo='{$_GET['lesson']}'";
                    $result = mysqli_query($con, $sql);
                    while ($row = $result->fetch_assoc()){
                        echo "Lesson Start Time: " . $row[$day] . "<br>";
                    }
					//If id has been set, there is a booking for this time
                    if(isset($_GET['id'])){
                        echo "<br>" . "Booking Reference: " . $_GET['bref'] . "<br>";
                        echo "<br>" . "Status: Booked ";
                    }
					//else, there is no booking here
                    else{
                        echo "<br>" . "Booking Reference: N/A" . "<br>";
                        echo "<br>" . "Status: Not Booked";                      
                    }               
                ?>
            </p>
        </div>
		<i-- This form allows the user to return to Table.php --></i-->
        <form class="btn1" action = "Table.php" method = "post">
             <input type = "submit" value = "  Return to Timetable  " name="return">
        </form>
		<i-- This form allows the user to create a booking --></i-->
        <form class="btn2" action = "" method = "post">
             <input type = "submit" value = "     Book this Date      " name="book">
        </form>
		<i-- This form allows the user to delete a booking --></i-->
        <form class="btn3" action = "" method = "post">
             <input type = "submit" value = " Remove this Booking " name="delete">
        </form>
    </body>
</html>
<?php 
//if the user has chosen to create a booking
    if(isset($_POST['book'])){
		//edit is made to equal true so that the correct timetable is generated on Table.php
        $_SESSION['edit']="True";
		//if id has been set, then there is a booking here so do not allow the user to proceed
        if(isset($_GET['id'])){
			echo "This room is already booked.";
		}
		//else, allow the user to proceed
        else {
			//insert into the Bookings table the specific booking
			$sql = "INSERT INTO `Bookings` (`RoomName`, `Username`, `Date`, `LessonNo`) VALUES ('{$_GET['room']}', '{$_SESSION['login_user']}', '{$_GET['date']}' , '{$_GET['lesson']}')";
            if ($con->query($sql) === TRUE) {
				//return the user to the previous page
               header("Location: Table.php");
            } 
            else {
                echo "Error: " . $sql . "<br>" . $con->error;
			}          
        }
    }
	//if the user has selected to remove a booking AND there is already a booking here
    if(isset($_POST['delete']) and isset($_GET['bref'])){
		//strip both usernames of spaces
		$temp=$string = preg_replace('/\s+/', '', $_GET['id']);
		$compare=preg_replace('/\s+/', '', $_SESSION['login_user']);
		//check if the owner of the booking is the user attempting to delete the booking
		//or if the user is an admin
		if (($temp==$compare) or ($_SESSION['Admin']==1)){
			//delete the selected booking from the Bookings table
			$sql="Delete FROM `Bookings` WHERE Date= '{$_GET['date']}' AND LessonNo='{$_GET['lesson']}'";
			$result = mysqli_query($con, $sql);
			//edit is made to equal true so that the correct timetable is generated on Table.php
			$_SESSION['edit']="True";
			//return the user to the previous page
			header("location: Table.php");
		}
		else {
			echo "You did not create this booking.";
		}
	}
?>