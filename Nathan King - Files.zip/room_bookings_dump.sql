-- MySQL dump 10.13  Distrib 5.5.53, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: room_bookings
-- ------------------------------------------------------
-- Server version       5.5.53-0ubuntu0.14.04.1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `Bookings`
--

DROP TABLE IF EXISTS `Bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Bookings` (
  `BookingNo` int(11) NOT NULL AUTO_INCREMENT,
  `RoomName` varchar(50) NOT NULL,
  `Username` varchar(50) NOT NULL,
  `Date` date NOT NULL,
  `LessonNo` int(11) NOT NULL,
  PRIMARY KEY (`BookingNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Bookings`
--

LOCK TABLES `Bookings` WRITE;
/*!40000 ALTER TABLE `Bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `Bookings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Lesson_Times`
--

DROP TABLE IF EXISTS `Lesson_Times`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Lesson_Times` (
  `LessonNo` int(11) NOT NULL,
  `TimeMT` time NOT NULL,
  `TimeF` time NOT NULL,
  PRIMARY KEY (`LessonNo`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Lesson_Times`
--

LOCK TABLES `Lesson_Times` WRITE;
/*!40000 ALTER TABLE `Lesson_Times` DISABLE KEYS */;
INSERT INTO `Lesson_Times` VALUES (1,'09:20:00','09:00:00'),(2,'10:35:00','10:15:00'),(3,'11:40:00','11:20:00'),(4,'13:25:00','13:05:00'),(5,'14:30:00','14:10:00');
/*!40000 ALTER TABLE `Lesson_Times` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Rooms`
--

DROP TABLE IF EXISTS `Rooms`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Rooms` (
  `RoomName` varchar(50) NOT NULL,
  `RoomResources` varchar(50) NOT NULL,  
  `ComputerNumber` int(11) NOT NULL,
  PRIMARY KEY (`RoomName`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Rooms`
--

LOCK TABLES `Rooms` WRITE;
/*!40000 ALTER TABLE `Rooms` DISABLE KEYS */;
INSERT INTO `Rooms` VALUES ('A6','IPW',19),('B17','IP',23),('B28','ISPW',21),('C6','ISP',17),('H7','ISPW',15),('J1','IW',21),('J2','IPW',22),('LearnCentre','PS',26);
/*!40000 ALTER TABLE `Rooms` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `Teacher`
--

DROP TABLE IF EXISTS `Teacher`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `Teacher` (
  `TeacherID` int(11) NOT NULL AUTO_INCREMENT,
  `Username` varchar(50) NOT NULL,
  `Password` varchar(50) NOT NULL,
  `IsAdmin` int(11) NOT NULL,
  PRIMARY KEY (`TeacherID`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `Teacher`
--

LOCK TABLES `Teacher` WRITE;
/*!40000 ALTER TABLE `Teacher` DISABLE KEYS */;
INSERT INTO `Teacher` VALUES (1,'N J King','81dc9bdb52d04dc20036dbd8313ed055',1),(2,'W T Hamilton','ce9dcab87d36681e7289e1034baa52b2',1),(3,'Admin','21232f297a57a5a743894a0e4a801fc3',1),(4,'D M Rooney',
'f5d7e2532cc9ad16bc2a41222d76f269',0),(5,'R G Milne','7d855282416ea1bfd7044ecba57e983e',0),(6,'N K Crawford-Smith','28abff9a3562e1bcedc906057b79e495',0),(7,'D M Gibson','37b4e2d82900d5e94b8da524fbeb33c0
',0),(8,'L J Fitts','24908ce13bfd3ec802bfc0ba32fc79e8',0),(9,'J A Hamilton','937bae4567f39d8303c2812c55cbd40c',0),(10,'R L Belson','669510bbf4ca7daf2e712ca140710953',0);
/*!40000 ALTER TABLE `Teacher` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2017-03-30 12:38:54